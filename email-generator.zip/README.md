# Lovable Email Generator

A simple AI-powered email generator using React and OpenAI.

## Deploy on Netlify
1. Click the button below
2. Set the `OPENAI_API_KEY` environment variable

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/wdm98p/email-generator)