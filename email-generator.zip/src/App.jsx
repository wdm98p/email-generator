import React from 'react';
import EmailGenerator from './EmailGenerator';
export default function App() {
  return <EmailGenerator />;
}